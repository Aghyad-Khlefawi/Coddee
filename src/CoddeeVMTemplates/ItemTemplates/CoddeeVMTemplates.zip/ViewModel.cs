﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Coddee.WPF;

namespace $rootnamespace$
{
    public class $fileinputname$ViewModel : ViewModelBase<$fileinputname$View>
    {
    }
}